<?php

return [

	// The default  value if the request match given action
	'active_state'		=>	'active',
	
	// The default  value if the request match given action
	'inactive_state'	=>	'no'

];