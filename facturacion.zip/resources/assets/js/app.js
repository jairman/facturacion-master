/* Jquery */
window.$ = window.jQuery = require('jquery');

require('bootstrap');

// AdminLTE code here. 
require('admin-lte');

/* bootstrap */
//require('bootstrap.bundle');

/* devbridge-autocomplete  */
require('devbridge-autocomplete');


/* toastr */
window.toastr = require('toastr');
toastr.options.preventDuplicates = true;


/* iCheck */
require('icheck');