<?php

return [

    /*
    |
    | Roles
    |
    */
    'admin' => 'Administrator',
    'user' => 'User',

    /*
    |
    | Permissions
    |
    */

    /* users */
    'view_users' => 'View users',
    'add_users' => 'Add users',
    'edit_users' => 'Edit users',
    'delete_users' => 'Delete users',
    'assign_permissions' => 'Assign permissions',
    'view_logins' => 'View logins',

];
