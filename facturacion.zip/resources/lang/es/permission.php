<?php

return [

    /*
    |
    | Roles
    |
    */
    'admin' => 'Administrador',
    'user' => 'Usuario',

    /*
    |
    | Permissions
    |
    */

    /* users */
    'view_users' => 'Ver usuarios',
    'add_users' => 'Agregar usuarios',
    'edit_users' => 'Editar usuarios',
    'delete_users' => 'Eliminar usuarios',
    'assign_permissions' => 'Asignar permisos',
    'view_logins' => 'Ver logins',

];
