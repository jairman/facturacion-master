<div class="col-md-4">
	<label class="">Tasa del día</label><br>
		 {!! Form::text('tasa', null,array('class' => 'form-control input-sm','placeholder'=>'Tasa ','id'=>'tasa')) !!}
</div>

<div class="col-md-4">
	<label class="">Tasa del día</label><br>
		 {!! Form::date('fe_tasa', null,array('class' => 'form-control input-sm','placeholder'=>'Seleccione','id'=>'txtFecha')) !!}
</div>