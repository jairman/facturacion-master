<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Facturación - <?php echo $__env->yieldContent('title'); ?></title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('images/logo/logo-imagen.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/we.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
  </head>

  <body class="hold-transition login-page" id="login">
    <!--Page Content Here -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- REQUIRED JS SCRIPTS -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pace.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>



  <style>
    
    #login{
      
      background-attachment: fixed;
      background-position: center center;
      background-size: cover;
       background-image: url("<?php echo e(asset('/images/fondo/hexagono.jpg')); ?>");    
            
    }
    
    </style>


  </body>
</html>
